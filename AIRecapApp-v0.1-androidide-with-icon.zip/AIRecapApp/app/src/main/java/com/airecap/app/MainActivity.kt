package com.airecap.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF07111A)
private val Card = Color(0xFF10202D)
private val Accent = Color(0xFF655CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

@Composable fun App() {
    var burmese by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("home") }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Accent)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "settings" -> SettingsScreen(burmese, { burmese = it }, { screen = "home" })
                "workflow" -> WorkflowScreen(burmese) { screen = "home" }
                else -> HomeScreen(burmese, { screen = "workflow" }, { screen = "settings" })
            }
        }
    }
}

@Composable fun TopBar(title: String, back: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) TextButton(onClick = back) { Text("‹", fontSize = 32.sp) }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun HomeScreen(mm: Boolean, start: () -> Unit, settings: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = settings) { Text("⚙") } }
        Spacer(Modifier.height(35.dp)); Text("▶", fontSize = 48.sp); Text("AI RECAP", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(if(mm) "ဗီဒီယိုကို မြန်မာ Recap အဖြစ် ပြောင်းပါ" else "Turn your video into a short recap", color = Color.LightGray)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(), placeholder = { Text(if(mm) "YouTube / TikTok link ထည့်ပါ" else "Paste YouTube / TikTok link") }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(12.dp)); Button(onClick = start, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) { Text(if(mm) "IMPORT" else "IMPORT") }
        Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = start, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) { Text(if(mm) "ဗီဒီယိုတင်မယ်" else "Upload Video") }
        Spacer(Modifier.height(40.dp)); Text(if(mm) "တစ်နေရာထဲမှာ Recap, Voice, Scene Cut, Subtitle အားလုံးလုပ်နိုင်မယ်" else "Recap, voice, scene cut and subtitles in one place", color = Color.Gray)
    }
}

@Composable fun WorkflowScreen(mm: Boolean, back: () -> Unit) {
    var recap by remember { mutableStateOf(true) }; var cut by remember { mutableStateOf(true) }; var clean by remember { mutableStateOf(false) }; var sub by remember { mutableStateOf(true) }; var male by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(if(mm) "AI Settings" else "AI Settings", back)
        Column(Modifier.padding(horizontal = 18.dp)) {
            CardBox { ToggleRow(if(mm) "AI Recap" else "AI Recap", recap) { recap = it }; ToggleRow(if(mm) "AI Scene Cut" else "AI Scene Cut", cut) { cut = it }; ToggleRow(if(mm) "AI Clean Video" else "AI Clean Video", clean) { clean = it }; ToggleRow(if(mm) "မြန်မာစာတန်းထိုး" else "Myanmar Subtitle", sub) { sub = it } }
            Spacer(Modifier.height(16.dp)); CardBox { Text(if(mm) "Voice" else "Voice", fontWeight = FontWeight.Bold); Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(male, { male = true }); Text(if(mm) "ယောကျ်ားအသံ" else "Male"); Spacer(Modifier.width(20.dp)); RadioButton(!male, { male = false }); Text(if(mm) "မိန်းကလေးအသံ" else "Female") } }
            Spacer(Modifier.height(16.dp)); CardBox { Text(if(mm) "Video အပိုင်းရွေးရန်" else "Select video range", fontWeight = FontWeight.Bold); Text("00:00:00  ━━━━━━━━━  00:30:00", color = Color.LightGray); Text(if(mm) "Start / End ကို နောက်ပိုင်းမှာ ဆွဲရွေးနိုင်မယ်" else "Drag start/end handles in the full version", color = Color.Gray) }
            Spacer(Modifier.height(24.dp)); Button(onClick = {}, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp)) { Text(if(mm) "GENERATE VIDEO" else "GENERATE VIDEO") }
            Spacer(Modifier.height(30.dp)); Text(if(mm) "Prototype v0.1 — AI/API processing မချိတ်ရသေးပါ" else "Prototype v0.1 — AI/API processing not connected yet", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable fun SettingsScreen(mm: Boolean, setMm: (Boolean) -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize()) { TopBar(if(mm) "ဆက်တင်များ" else "Settings", back); Column(Modifier.padding(18.dp)) {
        CardBox { Text(if(mm) "App Language" else "App Language", fontWeight = FontWeight.Bold); Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(!mm, { setMm(false) }); Text("English") }; Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(mm, { setMm(true) }); Text("မြန်မာ (Myanmar)") } }
    }}
}

@Composable fun CardBox(content: @Composable ColumnScope.() -> Unit) { Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), content = content) } }
@Composable fun ToggleRow(label: String, checked: Boolean, change: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Switch(checked, change) } }
