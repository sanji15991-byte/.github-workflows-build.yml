@echo off
setlocal
set ROOT_DIR=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Please use AndroidIDE or install Gradle 8.9.
exit /b 1
