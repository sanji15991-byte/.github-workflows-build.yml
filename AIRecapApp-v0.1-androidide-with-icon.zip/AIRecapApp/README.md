# AI Recap v0.1

AndroidIDE-ready prototype for the AI movie recap app.

Features in this prototype:
- YouTube / TikTok link input UI
- Upload video UI
- AI Recap toggle
- AI Scene Cut toggle
- AI Clean Video toggle
- Myanmar subtitle toggle
- Male / Female voice selection
- Myanmar / English UI switch
- Video range selection UI
- Generate Video button
- Custom AI Recap app icon included

Important: this is a UI prototype. Real YouTube/TikTok downloading, speech-to-text, AI recap generation, Myanmar TTS, scene matching, subtitle timing, watermark removal, and final video rendering are not connected yet.
